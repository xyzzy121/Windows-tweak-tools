* iTunes implementation based on
	- onlylyric by zlbruce (onlylyric.googlecode.com)
	- iTunesPlugin by Elestel (rainmeter.googlecode.com)

* WMP implementation based on
	- onlylyric by zlbruce (onlylyric.googlecode.com)
	- Last.fm WMP plugin (www.last.fm)